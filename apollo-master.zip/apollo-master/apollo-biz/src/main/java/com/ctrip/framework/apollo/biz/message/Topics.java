package com.ctrip.framework.apollo.biz.message;

/**
 * @author Jason Song(song_s@ctrip.com)
 */
public class Topics {
  public static final String APOLLO_RELEASE_TOPIC = "apollo-release";
}
